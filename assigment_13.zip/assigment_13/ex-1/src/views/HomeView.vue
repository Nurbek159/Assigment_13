<template>
  
</template>

<script>


export default {
  name: 'HomeView'
}
</script>
