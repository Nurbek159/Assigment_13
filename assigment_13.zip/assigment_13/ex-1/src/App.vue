<template>
    <div>
      <Timeline :events="timelineEvents" />
    </div>
  </template>
  
  <script>
  import Timeline from './components/Timeline.vue';
  
  export default {
    components: {
      Timeline
    },
    data() {
      return {
        timelineEvents: [
          {
            title: 'Event 1',
            date: '2023-01-01',
            description: 'Description of Event 1'
          },
          {
            title: 'Event 2',
            date: '2023-02-01',
            description: 'Description of Event 2'
          },
          {
            title: 'Event 3',
            date: '2023-03-01',
            description: 'Description of Event 3'
          }
        ]
      };
    }
  };
  </script>