<template>
    <div class="timeline">
      <div v-for="event in sortedEvents" :key="event.title" class="timeline-item">
        <div class="timeline-item-content">
          <h3>{{ event.title }}</h3>
          <p class="date">{{ event.date }}</p>
          <p>{{ event.description }}</p>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    props: {
      events: {
        type: Array,
        required: true
      }
    },
    computed: {
      sortedEvents() {
        // Sort events by date in ascending order
        return this.events.sort((a, b) => new Date(a.date) - new Date(b.date));
      }
    }
  };
  </script>
  
  <style>
  .timeline {
    border-left: 2px solid #ccc;
    position: relative;
    margin: 40px 0;
    padding: 0 20px;
  }
  
  .timeline-item {
    margin-bottom: 40px;
    position: relative;
  }
  
  .timeline-item-content {
    background-color: #f2f2f2;
    border-radius: 4px;
    padding: 20px;
    position: relative;
  }
  
  .date {
    color: #999;
  }
  
  .timeline:before {
    background-color: #ccc;
    content: "";
    position: absolute;
    left: 10px;
    top: 0;
    bottom: 0;
    width: 2px;
  }
  
  .timeline:before {
    left: -8px;
  }
  
  .timeline-item:first-child .timeline-item-content {
    margin-top: -20px;
    padding-top: 0;
  }
  
  .timeline-item:last-child .timeline-item-content {
    margin-bottom: -20px;
    padding-bottom: 0;
  }
  
  .timeline-item:before,
  .timeline-item:after {
    content: "";
    display: table;
  }
  
  .timeline-item:after {
    clear: both;
  }
  
  </style>