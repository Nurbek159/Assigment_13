<!-- App.vue -->
<template>
  <div id="app">
    <carousel :items="carouselItems"></carousel>
  </div>
</template>

<script>
import Carousel from './components/Carousel.vue';

export default {
  data() {
    return {
      carouselItems: [
        { src: 'Image 1', alt: 'Image 1', caption: 'Caption for Image 1' },
        { src: 'Image 2', alt: 'Image 2', caption: 'Caption for Image 2' },
        // Add more carousel items as needed
      ]
    };
  },
  components: {
    Carousel
  }
};
</script>