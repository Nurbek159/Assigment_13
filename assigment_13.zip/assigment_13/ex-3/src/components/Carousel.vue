<!-- components/Carousel.vue -->
<template>
    <div class="carousel">
      <div class="carousel-display">
        <img :src="currentItem.src" :alt="currentItem.alt">
        <div class="carousel-caption">{{ currentItem.caption }}</div>
      </div>
      <div class="carousel-controls">
        <button @click="prevItem" :disabled="currentIndex === 0">Previous</button>
        <button @click="nextItem" :disabled="currentIndex === items.length - 1">Next</button>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    props: {
      items: {
        type: Array,
        required: true
      }
    },
    data() {
      return {
        currentIndex: 0
      };
    },
    computed: {
      currentItem() {
        return this.items[this.currentIndex];
      }
    },
    methods: {
      nextItem() {
        if (this.currentIndex < this.items.length - 1) {
          this.currentIndex++;
        }
      },
      prevItem() {
        if (this.currentIndex > 0) {
          this.currentIndex--;
        }
      }
    }
  };
  </script>
  
  <style>
  .carousel {
    /* Add styling for the carousel container */
  }
  
  .carousel-display {
    /* Add styling for the display area */
  }
  
  .carousel-caption {
    /* Add styling for the caption */
  }
  
  .carousel-controls {
    /* Add styling for the navigation controls */
  }
  </style>